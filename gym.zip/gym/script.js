// const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');

// allSideMenu.forEach(item=> {
// 	const li = item.parentElement;

// 	item.addEventListener('click', function () {
// 		allSideMenu.forEach(img=> {
// 			img.parentElement.classList.remove('active');
// 		})
// 		li.classList.add('active');
// 	})
// });




// // TOGGLE SIDEBAR
// const menuBar = document.querySelector('.container .header-inner-wrap .primary');
// const sidebar = document.getElementById('sidebar');

// menuBar.addEventListener('click', function () {
// 	sidebar.classList.toggle('hide');
// })



